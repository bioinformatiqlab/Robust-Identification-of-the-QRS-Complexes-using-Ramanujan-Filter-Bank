This code is provided as-is for academic exploration. Cite the following paper if you use the code for your ACADEMIC research.

This project is intended for academic and research purposes only. Commercial or industrial use is discouraged without consulting the author(s) beforehand.

Sourav Kumar Mukhopadhyay and Sridhar Krishnan, “Single-Beat Myocardial Infarction Detection and Localization Using PSO-Optimized Extra Trees on 15-Lead ECG”, IEEE Transactions on Instrumentation and Measurement.
DOI: 10.1109/TIM.2025.3617406

The full code is available on request: sonartoritag@yahoo.co.in. Please send the email from your organizational/institutional email address.
